package com.alibaba.rocketmq.common.constant;


/**
 * User: yubao.fyb
 * Date: 14/11/13
 * Time: 14:11
 */
public class DBMsgConstants {
    public static final int maxBodySize = 64*1024*1204; //64KB
}
