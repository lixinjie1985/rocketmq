package com.alibaba.rocketmq.common.protocol;

/**
 * @author shijia.wxr<vintage.wang@gmail.com>
 */
public class MQProtosHelperTest {

}
