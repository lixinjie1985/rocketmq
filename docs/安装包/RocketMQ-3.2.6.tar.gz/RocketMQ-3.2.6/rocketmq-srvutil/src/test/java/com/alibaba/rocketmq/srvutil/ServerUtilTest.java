package com.alibaba.rocketmq.srvutil;

import org.junit.Test;


public class ServerUtilTest {
    @Test
    public void test1() {
        // TODO Auto-generated constructor stub
    }
}
