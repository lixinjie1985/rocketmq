/**
 *
 */
package com.alibaba.rocketmq.subclass;

import org.junit.Test;


/**
 * @author shijia.wxr<vintage.wang@gmail.com>
 */
public class TestSubClassAuto {
    @Test
    public void test_sub() {

    }
}
